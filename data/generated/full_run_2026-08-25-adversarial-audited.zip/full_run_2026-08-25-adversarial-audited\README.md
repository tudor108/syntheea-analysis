# Adversarially Audited Full Synthetic Run — 2026-08-25

This is the current complete `diagnostic-v2.0` package generated with seed 42.
It supersedes the earlier non-adversarial `full_run_2026-08-25` package.

> Synthetic demo data only. Not real Bayer, patient, clinical, commercial, or
> population data.

## Contents

- `gold/`: 19 CSV tables, 19 Parquet tables, and `prostate_journey.duckdb`.
- `reports/`: DQ, readiness, hostile independent audit, scorecards, schema,
  missingness, market/KPI summaries, dashboard, configuration snapshot and hashes.
- `configs/`: exact versioned scenario, market and clinical-rule inputs.
- `docs/`: architecture, rules, dictionary, quality and runbook documentation.
- `PROJECT_README.md` and `pyproject.toml`: project entry point and Python contract.

## Verified result

- 10,000 independent archetypes across all seven required markets.
- 28 automated tests passed; Ruff passed; no warnings.
- 90 data-quality rules passed with zero failures.
- Exact same-seed reproducibility across all 19 tables verified.
- Independent record-level persistence mismatches: zero for 3/6/12 months and
  30/60/90-day permissible gaps.
- Critical events after censor/death/LTFU: zero.
- Readiness score: 100/100; adversarial independent score: 100/100.
- P0 blockers: 0; P1 correctness issues: 0.

Start with `gold/patient_journey.parquet` for analysis or
`gold/prostate_journey.duckdb` for SQL. Use the normalized tables for all
reconciliation and longitudinal checks.
